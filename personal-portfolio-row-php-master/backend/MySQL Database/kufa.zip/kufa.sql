-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2021 at 07:18 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kufa`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` int(11) NOT NULL,
  `about_us` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=Active 2=Deleted '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`) VALUES
(1, 'UX/UI', 1),
(2, 'Web design', 1),
(3, 'Audio', 1),
(4, 'Video', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cetegories`
--

CREATE TABLE `cetegories` (
  `slog` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contact_information`
--

CREATE TABLE `contact_information` (
  `id` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contuct_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_information`
--

INSERT INTO `contact_information` (`id`, `address`, `contuct_desc`) VALUES
(2, 'Dhaka, Narsingdi, Monohardi, Labutala, Tarakandi', 'If you don\'t have confirmation of your residential address, you can upload a declaration letter - this is a letter from your family members																							');

-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE `counter` (
  `id` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `count_number` varchar(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Active 2=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counter`
--

INSERT INTO `counter` (`id`, `icon`, `count_number`, `title`, `status`) VALUES
(7, 'flaticon-award', '145', 'Feature Item', 1),
(8, 'flaticon-like', '500', 'Active Products', 1),
(9, 'flaticon-event', '50', 'Year Experience', 1),
(11, 'flaticon-woman', '3000', 'Our Clients', 1);

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `id` int(11) NOT NULL,
  `year` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `progress_bar` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Active 2=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id`, `year`, `title`, `progress_bar`, `status`) VALUES
(1, '2020', 'PHD of Interaction Design & Animation', '65%', 1),
(2, '2016', 'Master of Database Administration', '75%', 2),
(3, '2010', 'Bachelor of Computer Engineering', '85%', 1),
(4, '2005', 'Diploma of Computer', '90%', 2),
(6, '2005', 'Diploma of Computer', '90%', 1);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `send_time` timestamp NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Active 2=Deleted',
  `seen_status` int(11) NOT NULL DEFAULT 1 COMMENT '1=unseen 2=seen'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`, `send_time`, `status`, `seen_status`) VALUES
(1, 'Amdadul Haque Melon', 'amdadulhaquemelon15442@gmail.com', 'melon mia how are you ,,,,', '2021-07-07 11:16:57', 2, 2),
(2, 'Amdadul Haque Melon', 'amdadulhaquemelon15442@gmail.com', 'Event definition is - somthing that happens occurre How evesnt sentence. Synonym when an unknown printer took a galley.', '2021-07-07 11:16:57', 2, 2),
(11, 'Melon Mia', 'muktamoni@GMAIL.COM', 'HELLO AMDADUL HAQUE MELON', '2021-08-14 12:08:55', 1, 2),
(12, 'Amdadu Haque Melon', 'muktamoni@GMAIL.COM', 'i love u melon\r\n', '2021-08-14 12:37:59', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `patners`
--

CREATE TABLE `patners` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inictive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patners`
--

INSERT INTO `patners` (`id`, `image`, `status`) VALUES
(12, 'patner-1.png', 1),
(13, 'patner-13.png', 1),
(14, 'patner-14.png', 1),
(15, 'patner-15.png', 1),
(16, 'patner-16.png', 1),
(17, 'patner-17.png', 1),
(18, 'patner-18.png', 1),
(19, 'patner-19.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `portfolios`
--

CREATE TABLE `portfolios` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `feature_image` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `portfolios`
--

INSERT INTO `portfolios` (`id`, `title`, `slug`, `thumbnail`, `feature_image`, `description`, `category_id`, `status`) VALUES
(9, 'Landing Page', 'landing-page', 'landing-page-thumbnail-img-9.jpg', 'landing-page-feature-img-9.jpg', 'Express dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimem egestliberos dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretiumi Nullam justo efficitur, trist ligula pellentesque ipsum. Quisque t', 1, 1),
(10, 'Design', 'design', 'design-thumbnail-img-10.jpg', 'design-feature-img-10.jpg', 'Express dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimem egestliberos dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretiumi Nullam justo efficitur, trist ligula pellentesque ipsum. Quisque t', 2, 2),
(11, 'Audio Design', 'audio-design', 'audio-design-thumbnail-img-11.jpg', 'audio-design-feature-img-11.jpg', 'Express dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimem egestliberos dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretiumi Nullam justo efficitur, trist ligula pellentesque ipsum. Quisque t', 3, 1),
(12, 'Ipsum which', 'ipsum-which', 'ipsum-which-thumbnail-img-12.jpg', 'ipsum-which-feature-img-12.jpg', 'Express dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimem egestliberos dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretiumi Nullam justo efficitur, trist ligula pellentesque ipsum. Quisque t', 2, 1),
(13, 'Eiusmod tempor', 'eiusmod-tempor', 'eiusmod-tempor-thumbnail-img-13.jpg', 'eiusmod-tempor-feature-img-13.jpg', 'Express dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimem egestliberos dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretiumi Nullam justo efficitur, trist ligula pellentesque ipsum. Quisque t', 4, 1),
(14, 'Dark Beauty', 'dark-beauty', 'dark-beauty-thumbnail-img-14.jpg', 'dark-beauty-feature-img-14.jpg', 'Express dolor sit amet, consectetur adipiscing elit. Cras sollicitudin, tellus vitae condimem egestliberos dolor auctor tellus, eu consectetur neque elit quis nunc. Cras elementum pretiumi Nullam justo efficitur, trist ligula pellentesque ipsum. Quisque t', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Deactivated'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `icon`, `status`) VALUES
(1, 'Creative Design', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum indust. ', 'fab fa-react', 1),
(2, 'Unlimited Features', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum indust. ', 'fab fa-free-code-camp', 1),
(3, 'Ultra Responsive', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum indust. ', 'fal fa-desktop', 1),
(4, 'Creative Ideas', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum indust. ', 'fal fa-lightbulb-on', 1),
(5, 'Easy Customization', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum indust. ', 'fal fa-edit', 1),
(6, 'Supper Support', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum indust. ', 'fal fa-headset', 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `website_name` varchar(255) NOT NULL,
  `logo_white` varchar(255) NOT NULL,
  `logo_black` varchar(255) NOT NULL,
  `favicon` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `website_name`, `logo_white`, `logo_black`, `favicon`) VALUES
(1, 'Parnonal Portfolio', 'logo-white.png', 'logo-black.png', 'favicon.png');

-- --------------------------------------------------------

--
-- Table structure for table `social_links`
--

CREATE TABLE `social_links` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `social_links`
--

INSERT INTO `social_links` (`id`, `name`, `link`, `icon`, `status`) VALUES
(1, 'Facbook', 'https://www.facebook.com/amdadulhaquemelonmia/', 'fab fa-facebook-f', 0),
(2, 'Linkedin', 'https://www.linkedin.com/in/amdadulhaquemelon/', 'fab fa-linkedin-in', 0),
(3, 'Twitter', 'https://twitter.com/AmdadulMelon', 'fab fa-twitter', 0);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `profile_img` varchar(255) DEFAULT NULL,
  `comment` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rank` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Active 2=Inactive '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `profile_img`, `comment`, `name`, `rank`, `status`) VALUES
(10, 'tonoy-jakson.jpg', ' An event is a message sent by an object to signal the occur rence of an action. The action can causd user interaction such as a button click, or it can result ', 'tonoy jakson', 'tonoy jakson', 1),
(11, 'melon-mia.png', ' An event is a message sent by an object to signal the occur rence of an action. The action can causd user interaction such as a button click, or it can result ', 'Melon Mia', 'Melon Mia', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `about_me` varchar(255) DEFAULT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `states` int(11) NOT NULL DEFAULT 1 COMMENT '1=active 2=deactivate',
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `about_me`, `phone`, `email`, `password`, `states`, `photo`) VALUES
(19, 'Amdadul Haque', 'Seasoned and independent Full-stack Web Developer in blending the art of design with the skill of programming.', '01617253586', 'karnoder@gmail.com', '$2y$10$CJk.NzDsl8I2lN923pikMehWw57p2mGxPtw7dUc39d9NOiyY/8iUq', 1, 'karnoder-19.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_information`
--
ALTER TABLE `contact_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `counter`
--
ALTER TABLE `counter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patners`
--
ALTER TABLE `patners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolios`
--
ALTER TABLE `portfolios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_links`
--
ALTER TABLE `social_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact_information`
--
ALTER TABLE `contact_information`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `counter`
--
ALTER TABLE `counter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `patners`
--
ALTER TABLE `patners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `portfolios`
--
ALTER TABLE `portfolios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `social_links`
--
ALTER TABLE `social_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
